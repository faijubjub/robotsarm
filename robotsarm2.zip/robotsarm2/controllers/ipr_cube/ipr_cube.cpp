// Copyright 1996-2020 Cyberbotics Ltd.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Description:   Simple program to handle a cube with the IPR

#include "IPR.hpp"

#include <webots/DistanceSensor.hpp>
#include <webots/Robot.hpp>

using namespace webots;

#define OBJECT_NUMBER 4
//double gGrabPosition[] = {3.00660, -1.35619, 1.19083, -3.24647, -2.94524, 0.727475, -0.727475};
//double gDropPosition[] = {5.09282, 0.00000, 3.08698, -1.34990, -2.82252, 0.727475, -0.727475};
double gGrabPosition[] = {3.00660, -0.79619, 1.19083, -3.44647, -2.94524, 0.727475, -0.727475};
double gDropPosition[] = {4.59282, -1.13619, 1.18698, -3.44990, -2.82252, 0.727475, -0.727475};
double gGrabPosition2[] = {3.00660, -0.9619, 1.09083, -3.24647, -2.94524, 0.727475, -0.727475};
double gDropPosition2[] = {6.00000, -1.13619, 1.18698, -3.44990, -2.82252, 0.727475, -0.727475};
double gGrabPosition3[] = {3.00660, -1.1119, 1.09083, -3.24647, -2.94524, 0.727475, -0.727475};
double gDropPosition3[] = {1.50000, -1.13619, 1.18698, -3.44990, -2.82252, 0.727475, -0.727475};
double gGrabPosition4[] = {3.00660, -1.33619, 1.19083, -3.24647, -2.94524, 0.727475, -0.727475};
double gDropPosition4[] = {0.50000, -1.13619, 1.08698, -3.44990, -2.82252, 0.727475, -0.727475};

int main(int argc, char **argv) {
  IPR *ipr = new IPR();

  ipr->grabCube(gGrabPosition);
  ipr->dropCube(gDropPosition);
  ipr->grabCube(gGrabPosition2);
  ipr->dropCube(gDropPosition2);
  ipr->grabCube(gGrabPosition3);
  ipr->dropCube(gDropPosition3);
  ipr->grabCube(gGrabPosition4);
  ipr->dropCube(gDropPosition4);
  ipr->moveToInitPosition();

  delete ipr;
  return 0;
}
